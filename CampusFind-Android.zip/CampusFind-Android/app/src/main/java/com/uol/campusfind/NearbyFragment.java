package com.uol.campusfind;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.progressindicator.CircularProgressIndicator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class NearbyFragment extends LocationFragment {
    private static class Near {
        Item item;
        float dist;
    }

    private ItemAdapter adapter;
    private TextView status;
    private CircularProgressIndicator progress;
    private boolean loaded = false;
    private double curLat, curLng;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle b) {
        return inf.inflate(R.layout.fragment_nearby, parent, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        status = v.findViewById(R.id.tv_status);
        progress = v.findViewById(R.id.progress);
        RecyclerView rv = v.findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ItemAdapter(item -> {
            Intent i = new Intent(requireContext(), DetailsActivity.class);
            i.putExtra("id", item.id);
            startActivity(i);
        });
        rv.setAdapter(adapter);
        v.findViewById(R.id.btn_refresh).setOnClickListener(x -> fetchLocation());
        fetchLocation();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden && loaded) showList();
    }

    private void fetchLocation() {
        progress.setVisibility(View.VISIBLE);
        status.setText("Getting your location...");
        requestLocation(new Callback() {
            @Override
            public void onLocation(double lat, double lng) {
                progress.setVisibility(View.GONE);
                curLat = lat;
                curLng = lng;
                loaded = true;
                showList();
            }

            @Override
            public void onError(String message) {
                progress.setVisibility(View.GONE);
                status.setText(message);
            }
        });
    }

    private void showList() {
        List<Item> items = DbHelper.get(requireContext()).items();
        List<Near> near = new ArrayList<>();
        float[] res = new float[1];
        for (Item i : items) {
            Location.distanceBetween(curLat, curLng, i.lat, i.lng, res);
            Near n = new Near();
            n.item = i;
            n.dist = res[0];
            near.add(n);
        }
        Collections.sort(near, new Comparator<Near>() {
            @Override
            public int compare(Near a, Near b) {
                return Float.compare(a.dist, b.dist);
            }
        });
        List<Item> sorted = new ArrayList<>();
        List<String> dist = new ArrayList<>();
        for (Near n : near) {
            sorted.add(n.item);
            dist.add(Util.fmtDistance(n.dist));
        }
        adapter.setData(sorted, dist);
        status.setText("Your location: " + Util.coord(curLat) + ", " + Util.coord(curLng)
                + "\nItems sorted nearest first");
    }
}
