package com.uol.campusfind;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.button.MaterialButton;

public class ProfileFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle b) {
        return inf.inflate(R.layout.fragment_profile, parent, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        MainActivity main = (MainActivity) requireActivity();
        TextView initial = v.findViewById(R.id.tv_initial);
        initial.setText(main.userName.isEmpty() ? "?" : main.userName.substring(0, 1).toUpperCase());
        initial.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.primary)));
        initial.setTextColor(ContextCompat.getColor(requireContext(), R.color.white));
        ((TextView) v.findViewById(R.id.tv_name)).setText(main.userName);
        ((TextView) v.findViewById(R.id.tv_email)).setText(main.userEmail);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Config.TEAM_MEMBERS.length; i++) {
            if (i > 0) sb.append("\n");
            sb.append("\u2022  ").append(Config.TEAM_MEMBERS[i]);
        }
        ((TextView) v.findViewById(R.id.tv_team)).setText(sb.toString());

        MaterialButton gh = v.findViewById(R.id.btn_github);
        gh.setText(Config.GITHUB_URL);
        gh.setOnClickListener(x -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Config.GITHUB_URL)));
            } catch (Exception e) {
                Toast.makeText(requireContext(), "Could not open link", Toast.LENGTH_SHORT).show();
            }
        });

        v.findViewById(R.id.btn_logout).setOnClickListener(x -> {
            Session.clear(requireContext());
            Intent i = new Intent(requireContext(), LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            requireActivity().finish();
        });
    }
}
