package com.uol.campusfind;

import android.content.Context;
import android.content.SharedPreferences;

public final class Session {
    private Session() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("campusfind_session", Context.MODE_PRIVATE);
    }

    public static void save(Context c, String email) {
        p(c).edit().putString("email", email).apply();
    }

    public static void clear(Context c) {
        p(c).edit().remove("email").apply();
    }

    public static String getEmail(Context c) {
        return p(c).getString("email", null);
    }
}
