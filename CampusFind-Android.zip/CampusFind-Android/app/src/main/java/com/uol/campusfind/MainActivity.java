package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    private static final String[] TAGS = {"home", "nearby", "report", "profile"};

    public String userName, userEmail;
    private BottomNavigationView bottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String[] u = DbHelper.get(this).getUser(Session.getEmail(this));
        if (u == null) {
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
            return;
        }
        userName = u[0];
        userEmail = u[1];
        setContentView(R.layout.activity_main);
        bottom = findViewById(R.id.bottom_nav);
        bottom.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) showTab("home");
            else if (id == R.id.nav_nearby) showTab("nearby");
            else if (id == R.id.nav_report) showTab("report");
            else showTab("profile");
            return true;
        });
        if (savedInstanceState == null) bottom.setSelectedItemId(R.id.nav_home);
    }

    private Fragment make(String tag) {
        switch (tag) {
            case "nearby": return new NearbyFragment();
            case "report": return new ReportFragment();
            case "profile": return new ProfileFragment();
            default: return new HomeFragment();
        }
    }

    private void showTab(String tag) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction t = fm.beginTransaction();
        for (String s : TAGS) {
            Fragment f = fm.findFragmentByTag(s);
            if (f != null && !s.equals(tag)) t.hide(f);
        }
        Fragment target = fm.findFragmentByTag(tag);
        if (target == null) {
            t.add(R.id.container, make(tag), tag);
        } else {
            t.show(target);
        }
        t.commit();
    }

    public void goHome() {
        bottom.setSelectedItemId(R.id.nav_home);
    }

    public void snack(String msg) {
        Snackbar s = Snackbar.make(findViewById(R.id.main_root), msg, Snackbar.LENGTH_LONG);
        s.setAnchorView(bottom);
        s.show();
    }
}
