package com.uol.campusfind;

public class Item {
    public String id, type, title, category, place, contact, date, reporter, reporterEmail, status;
    public int seq;
    public double lat, lng;
}
