package com.uol.campusfind;

import android.content.Context;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class Util {
    private Util() {}

    public static String fmtDate(String iso) {
        try {
            Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso);
            return new SimpleDateFormat("dd-MMM-yyyy", Locale.US).format(d);
        } catch (Exception e) {
            return iso;
        }
    }

    public static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    public static String fmtDistance(double m) {
        if (m < 1000) return String.format(Locale.US, "%d m", Math.round(m));
        return String.format(Locale.US, "%.1f km", m / 1000.0);
    }

    public static String coord(double v) {
        return String.format(Locale.US, "%.5f", v);
    }

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static String str(EditText e) {
        return e.getText() == null ? "" : e.getText().toString();
    }

    public static boolean validName(String s) {
        s = s.trim();
        return s.length() >= 3 && s.matches("[A-Za-z ]+");
    }

    public static boolean validEmail(String s) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(s.trim()).matches();
    }

    public static boolean validPassword(String s) {
        return s.length() >= 6 && s.matches(".*\\d.*");
    }
}
