package com.uol.campusfind;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

public class DetailsActivity extends AppCompatActivity {
    private Item item;
    private String myEmail;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_details);
        myEmail = Session.getEmail(this);
        item = DbHelper.get(this).getItem(getIntent().getStringExtra("id"));
        if (item == null) {
            finish();
            return;
        }
        com.google.android.material.appbar.MaterialToolbar tb = findViewById(R.id.toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        findViewById(R.id.btn_maps).setOnClickListener(v -> openMaps());
        findViewById(R.id.btn_return).setOnClickListener(v -> confirmReturn());
        render();
    }

    private void render() {
        ((TextView) findViewById(R.id.tv_title)).setText(item.title);
        LinearLayout rows = findViewById(R.id.rows);
        rows.removeAllViews();
        addRow(rows, "ID", item.id);
        addRow(rows, "Type", item.type);
        addRow(rows, "Title", item.title);
        addRow(rows, "Category", item.category);
        addRow(rows, "Place", item.place);
        addRow(rows, "Date", Util.fmtDate(item.date));
        addRow(rows, "Coordinates", Util.coord(item.lat) + ", " + Util.coord(item.lng));
        addRow(rows, "Reported by", item.reporter);
        if (!item.contact.isEmpty()) addRow(rows, "Contact", item.contact);
        addRow(rows, "Status", item.status);
        boolean mine = item.reporterEmail != null && item.reporterEmail.equals(myEmail);
        findViewById(R.id.btn_return).setVisibility(
                mine && "Open".equals(item.status) ? View.VISIBLE : View.GONE);
    }

    private void addRow(LinearLayout parent, String k, String v) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, Util.dp(this, 6), 0, Util.dp(this, 6));
        TextView a = new TextView(this);
        a.setText(k);
        a.setTextColor(ContextCompat.getColor(this, R.color.on_surface_variant));
        a.setLayoutParams(new LinearLayout.LayoutParams(Util.dp(this, 110),
                LinearLayout.LayoutParams.WRAP_CONTENT));
        TextView c = new TextView(this);
        c.setText(v);
        c.setTypeface(null, Typeface.BOLD);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(a);
        row.addView(c);
        parent.addView(row);
    }

    private void openMaps() {
        String label = Uri.encode(item.title);
        Uri geo = Uri.parse("geo:" + item.lat + "," + item.lng + "?q=" + item.lat + "," + item.lng + "(" + label + ")");
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, geo));
        } catch (ActivityNotFoundException e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(
                        "https://www.google.com/maps/search/?api=1&query=" + item.lat + "," + item.lng)));
            } catch (Exception ex) {
                Snackbar.make(findViewById(R.id.root), "No maps app found", Snackbar.LENGTH_LONG).show();
            }
        }
    }

    private void confirmReturn() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Mark as Returned?")
                .setMessage("This item will stay in the list with a RETURNED tag.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Confirm", (d, w) -> {
                    DbHelper.get(this).markReturned(item.id);
                    item.status = "Returned";
                    render();
                    Snackbar.make(findViewById(R.id.root), "Marked as Returned", Snackbar.LENGTH_LONG).show();
                })
                .show();
    }
}
