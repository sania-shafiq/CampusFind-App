package com.uol.campusfind;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class ReportFragment extends LocationFragment {
    private MaterialButtonToggleGroup typeGroup;
    private TextInputLayout tilTitle, tilCategory, tilPlace, tilContact;
    private TextInputEditText etTitle, etPlace, etContact;
    private MaterialAutoCompleteTextView actCategory;
    private TextView tvCoords, tvLocError;
    private Double lat, lng;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle b) {
        return inf.inflate(R.layout.fragment_report, parent, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        typeGroup = v.findViewById(R.id.type_group);
        typeGroup.check(R.id.btn_lost);
        tilTitle = v.findViewById(R.id.til_title);
        tilCategory = v.findViewById(R.id.til_category);
        tilPlace = v.findViewById(R.id.til_place);
        tilContact = v.findViewById(R.id.til_contact);
        etTitle = v.findViewById(R.id.et_title);
        etPlace = v.findViewById(R.id.et_place);
        etContact = v.findViewById(R.id.et_contact);
        actCategory = v.findViewById(R.id.act_category);
        tvCoords = v.findViewById(R.id.tv_coords);
        tvLocError = v.findViewById(R.id.tv_loc_error);
        actCategory.setAdapter(new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_list_item_1, Config.CATEGORIES));
        v.findViewById(R.id.btn_loc).setOnClickListener(x -> getLocation());
        v.findViewById(R.id.btn_submit).setOnClickListener(x -> save());
    }

    private void getLocation() {
        tvLocError.setVisibility(View.GONE);
        tvCoords.setText("Getting location...");
        requestLocation(new Callback() {
            @Override
            public void onLocation(double la, double lo) {
                lat = la;
                lng = lo;
                showCoords();
            }

            @Override
            public void onError(String message) {
                lat = null;
                lng = null;
                showCoords();
                tvLocError.setText(message);
                tvLocError.setVisibility(View.VISIBLE);
                ((MainActivity) requireActivity()).snack(message);
            }
        });
    }

    private void showCoords() {
        if (lat == null) {
            tvCoords.setText("No location tagged yet");
        } else {
            tvCoords.setText("Latitude: " + Util.coord(lat) + "\nLongitude: " + Util.coord(lng));
        }
    }

    private void save() {
        tilTitle.setError(null);
        tilCategory.setError(null);
        tilPlace.setError(null);
        tilContact.setError(null);
        String title = Util.str(etTitle).trim();
        String category = actCategory.getText() == null ? "" : actCategory.getText().toString().trim();
        String place = Util.str(etPlace).trim();
        String contact = Util.str(etContact).trim();
        boolean bad = false;
        if (title.length() < 3) { tilTitle.setError("Title must be at least 3 characters"); bad = true; }
        if (category.isEmpty()) { tilCategory.setError("Select a category"); bad = true; }
        if (place.isEmpty()) { tilPlace.setError("Place is required"); bad = true; }
        if (!contact.matches("03\\d{9}")) { tilContact.setError("Enter 11 digits starting with 03"); bad = true; }
        if (lat == null || lng == null) {
            tvLocError.setText("Tap \"Use my current location\" to tag this item");
            tvLocError.setVisibility(View.VISIBLE);
            bad = true;
        }
        if (bad) return;

        MainActivity main = (MainActivity) requireActivity();
        String type = typeGroup.getCheckedButtonId() == R.id.btn_found ? "Found" : "Lost";
        String id = DbHelper.get(requireContext()).addItem(type, title, category, place, contact,
                lat, lng, main.userName, main.userEmail);

        etTitle.setText("");
        etPlace.setText("");
        etContact.setText("");
        actCategory.setText("", false);
        typeGroup.check(R.id.btn_lost);
        lat = null;
        lng = null;
        showCoords();
        tvLocError.setVisibility(View.GONE);
        main.goHome();
        main.snack("Item " + id + " reported");
    }
}
