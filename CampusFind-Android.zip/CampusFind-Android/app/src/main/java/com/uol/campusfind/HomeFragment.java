package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HomeFragment extends Fragment {
    private ItemAdapter adapter;
    private List<Item> all = new ArrayList<>();
    private TextInputEditText etSearch;
    private ChipGroup chips;
    private TextView empty;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle b) {
        return inf.inflate(R.layout.fragment_home, parent, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        etSearch = v.findViewById(R.id.et_search);
        chips = v.findViewById(R.id.chips);
        empty = v.findViewById(R.id.tv_empty);
        RecyclerView rv = v.findViewById(R.id.recycler);
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new ItemAdapter(item -> {
            Intent i = new Intent(requireContext(), DetailsActivity.class);
            i.putExtra("id", item.id);
            startActivity(i);
        });
        rv.setAdapter(adapter);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { apply(); }
            @Override public void afterTextChanged(Editable e) { }
        });
        chips.setOnCheckedStateChangeListener((g, ids) -> apply());
        load();
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) load();
    }

    private void load() {
        if (adapter == null) return;
        all = DbHelper.get(requireContext()).items();
        apply();
    }

    private void apply() {
        int id = chips.getCheckedChipId();
        String f = id == R.id.chip_lost ? "Lost" : id == R.id.chip_found ? "Found" : "All";
        String q = Util.str(etSearch).trim().toLowerCase(Locale.US);
        List<Item> out = new ArrayList<>();
        for (Item i : all) {
            if (!f.equals("All") && !i.type.equals(f)) continue;
            if (!q.isEmpty() && !(i.title.toLowerCase(Locale.US).contains(q)
                    || i.place.toLowerCase(Locale.US).contains(q)
                    || i.category.toLowerCase(Locale.US).contains(q))) continue;
            out.add(i);
        }
        adapter.setData(out, null);
        empty.setVisibility(out.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
