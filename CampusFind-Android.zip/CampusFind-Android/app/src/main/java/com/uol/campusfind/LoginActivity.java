package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {
    private TextInputLayout tilEmail, tilPass;
    private TextInputEditText etEmail, etPass;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String saved = Session.getEmail(this);
        if (saved != null && DbHelper.get(this).getUser(saved) != null) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_login);
        tilEmail = findViewById(R.id.til_email);
        tilPass = findViewById(R.id.til_password);
        etEmail = findViewById(R.id.et_email);
        etPass = findViewById(R.id.et_password);
        findViewById(R.id.btn_login).setOnClickListener(v -> submit());
        findViewById(R.id.btn_to_register).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void submit() {
        tilEmail.setError(null);
        tilPass.setError(null);
        String email = Util.str(etEmail).trim();
        String pass = Util.str(etPass);
        boolean bad = false;
        if (email.isEmpty()) { tilEmail.setError("Email is required"); bad = true; }
        if (pass.isEmpty()) { tilPass.setError("Password is required"); bad = true; }
        if (bad) return;

        String ok = DbHelper.get(this).login(email, pass);
        if (ok == null) {
            Snackbar.make(findViewById(R.id.root), "Invalid email or password", Snackbar.LENGTH_LONG).show();
            return;
        }
        Session.save(this, ok);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
