package com.uol.campusfind;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;
import androidx.fragment.app.Fragment;

public abstract class LocationFragment extends Fragment {
    public interface Callback {
        void onLocation(double lat, double lng);
        void onError(String message);
    }

    protected static final String DENIED = "Location permission is required to tag this item";
    private Callback pending;

    private final ActivityResultLauncher<String[]> permLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (hasPermission()) fetch(); else fail(DENIED);
            });

    private boolean hasPermission() {
        Context c = requireContext();
        return ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    protected void requestLocation(Callback cb) {
        pending = cb;
        if (hasPermission()) {
            fetch();
        } else {
            permLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION});
        }
    }

    private void fail(String msg) {
        Callback cb = pending;
        pending = null;
        if (cb != null && isAdded()) cb.onError(msg);
    }

    private void ok(Location l) {
        Callback cb = pending;
        pending = null;
        if (cb != null && isAdded()) {
            cb.onLocation(Math.round(l.getLatitude() * 1e5) / 1e5, Math.round(l.getLongitude() * 1e5) / 1e5);
        }
    }

    @SuppressLint("MissingPermission")
    private void fetch() {
        try {
            final LocationManager lm = (LocationManager) requireContext().getSystemService(Context.LOCATION_SERVICE);
            final String provider;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) provider = LocationManager.GPS_PROVIDER;
            else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) provider = LocationManager.NETWORK_PROVIDER;
            else {
                fail("Please turn on device location (GPS)");
                return;
            }
            LocationManagerCompat.getCurrentLocation(lm, provider, null,
                    ContextCompat.getMainExecutor(requireContext()), loc -> {
                        if (loc != null) {
                            ok(loc);
                            return;
                        }
                        Location last = null;
                        try {
                            last = lm.getLastKnownLocation(provider);
                        } catch (SecurityException ignored) { }
                        if (last != null) ok(last);
                        else fail("Could not get location. Set a location in the emulator (... > Location) and try again.");
                    });
        } catch (SecurityException e) {
            fail(DENIED);
        } catch (Exception e) {
            fail("Could not get location. Please try again.");
        }
    }
}
