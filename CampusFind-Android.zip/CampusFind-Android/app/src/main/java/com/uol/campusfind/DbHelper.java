package com.uol.campusfind;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DbHelper extends SQLiteOpenHelper {
    private static DbHelper inst;

    public static synchronized DbHelper get(Context c) {
        if (inst == null) inst = new DbHelper(c.getApplicationContext());
        return inst;
    }

    private DbHelper(Context c) {
        super(c, "campusfind.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, "
                + "email TEXT NOT NULL UNIQUE, pass_hash TEXT NOT NULL, salt TEXT NOT NULL)");
        db.execSQL("CREATE TABLE items(id TEXT PRIMARY KEY, seq INTEGER NOT NULL, type TEXT NOT NULL, "
                + "title TEXT NOT NULL, category TEXT NOT NULL, place TEXT NOT NULL, contact TEXT, "
                + "date TEXT NOT NULL, lat REAL NOT NULL, lng REAL NOT NULL, reporter TEXT NOT NULL, "
                + "reporter_email TEXT NOT NULL, status TEXT NOT NULL)");
        Object[][] seed = {
                {"Found", "Black leather wallet", "Wallets & Cards", "Main Library", "2026-11-12", 31.38955, 74.24070},
                {"Lost", "Casio fx-991ES calculator", "Electronics", "CS Block", "2026-11-11", 31.38990, 74.24120},
                {"Found", "Student ID card", "Wallets & Cards", "Cafeteria", "2026-11-10", 31.38880, 74.24010},
                {"Lost", "Blue water bottle", "Other", "Sports Ground", "2026-11-09", 31.38800, 74.24200},
                {"Found", "Car keys, red keychain", "Keys", "Main Parking", "2026-11-08", 31.39050, 74.23950},
                {"Lost", "32 GB USB flash drive", "Electronics", "Mosque", "2026-11-07", 31.38920, 74.24180}
        };
        for (int i = 0; i < seed.length; i++) {
            ContentValues v = new ContentValues();
            v.put("id", String.format(Locale.US, "CF-%02d", i + 1));
            v.put("seq", i + 1);
            v.put("type", (String) seed[i][0]);
            v.put("title", (String) seed[i][1]);
            v.put("category", (String) seed[i][2]);
            v.put("place", (String) seed[i][3]);
            v.put("contact", "");
            v.put("date", (String) seed[i][4]);
            v.put("lat", (Double) seed[i][5]);
            v.put("lng", (Double) seed[i][6]);
            v.put("reporter", "Student Affairs");
            v.put("reporter_email", "student.affairs@system");
            v.put("status", "Open");
            db.insert("items", null, v);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) { }

    // ---------- auth ----------
    private static String hash(String salt, String pass) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest((salt + ":" + pass).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String newSalt() {
        byte[] b = new byte[16];
        new SecureRandom().nextBytes(b);
        return Base64.encodeToString(b, Base64.NO_WRAP);
    }

    /** @return false if the email already exists */
    public boolean register(String name, String email, String pass) {
        String e = email.trim().toLowerCase(Locale.US);
        SQLiteDatabase db = getWritableDatabase();
        try (Cursor c = db.rawQuery("SELECT 1 FROM users WHERE email=?", new String[]{e})) {
            if (c.moveToFirst()) return false;
        }
        String salt = newSalt();
        ContentValues v = new ContentValues();
        v.put("name", name.trim());
        v.put("email", e);
        v.put("salt", salt);
        v.put("pass_hash", hash(salt, pass));
        return db.insert("users", null, v) != -1;
    }

    /** @return the user's email if the login is valid, otherwise null */
    public String login(String email, String pass) {
        String e = email.trim().toLowerCase(Locale.US);
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT pass_hash, salt FROM users WHERE email=?", new String[]{e})) {
            if (!c.moveToFirst()) return null;
            String ph = c.getString(0), salt = c.getString(1);
            return hash(salt, pass).equals(ph) ? e : null;
        }
    }

    /** @return {name, email} or null */
    public String[] getUser(String email) {
        if (email == null) return null;
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT name, email FROM users WHERE email=?", new String[]{email})) {
            if (!c.moveToFirst()) return null;
            return new String[]{c.getString(0), c.getString(1)};
        }
    }

    // ---------- items ----------
    private static Item read(Cursor c) {
        Item i = new Item();
        i.id = c.getString(c.getColumnIndexOrThrow("id"));
        i.seq = c.getInt(c.getColumnIndexOrThrow("seq"));
        i.type = c.getString(c.getColumnIndexOrThrow("type"));
        i.title = c.getString(c.getColumnIndexOrThrow("title"));
        i.category = c.getString(c.getColumnIndexOrThrow("category"));
        i.place = c.getString(c.getColumnIndexOrThrow("place"));
        String ct = c.getString(c.getColumnIndexOrThrow("contact"));
        i.contact = ct == null ? "" : ct;
        i.date = c.getString(c.getColumnIndexOrThrow("date"));
        i.lat = c.getDouble(c.getColumnIndexOrThrow("lat"));
        i.lng = c.getDouble(c.getColumnIndexOrThrow("lng"));
        i.reporter = c.getString(c.getColumnIndexOrThrow("reporter"));
        i.reporterEmail = c.getString(c.getColumnIndexOrThrow("reporter_email"));
        i.status = c.getString(c.getColumnIndexOrThrow("status"));
        return i;
    }

    public List<Item> items() {
        List<Item> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM items ORDER BY date DESC, seq DESC", null)) {
            while (c.moveToNext()) list.add(read(c));
        }
        return list;
    }

    public Item getItem(String id) {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT * FROM items WHERE id=?", new String[]{id})) {
            return c.moveToFirst() ? read(c) : null;
        }
    }

    public String addItem(String type, String title, String category, String place, String contact,
                          double lat, double lng, String reporter, String reporterEmail) {
        SQLiteDatabase db = getWritableDatabase();
        int next = 1;
        try (Cursor c = db.rawQuery("SELECT MAX(seq) FROM items", null)) {
            if (c.moveToFirst()) next = c.getInt(0) + 1;
        }
        String id = String.format(Locale.US, "CF-%02d", next);
        ContentValues v = new ContentValues();
        v.put("id", id);
        v.put("seq", next);
        v.put("type", type);
        v.put("title", title.trim());
        v.put("category", category);
        v.put("place", place.trim());
        v.put("contact", contact.trim());
        v.put("date", Util.today());
        v.put("lat", lat);
        v.put("lng", lng);
        v.put("reporter", reporter);
        v.put("reporter_email", reporterEmail);
        v.put("status", "Open");
        db.insert("items", null, v);
        return id;
    }

    public void markReturned(String id) {
        ContentValues v = new ContentValues();
        v.put("status", "Returned");
        getWritableDatabase().update("items", v, "id=?", new String[]{id});
    }
}
