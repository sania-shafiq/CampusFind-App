package com.uol.campusfind;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class RegisterActivity extends AppCompatActivity {
    private TextInputLayout tilName, tilEmail, tilPass, tilConfirm;
    private TextInputEditText etName, etEmail, etPass, etConfirm;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_register);
        tilName = findViewById(R.id.til_name);
        tilEmail = findViewById(R.id.til_email);
        tilPass = findViewById(R.id.til_password);
        tilConfirm = findViewById(R.id.til_confirm);
        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPass = findViewById(R.id.et_password);
        etConfirm = findViewById(R.id.et_confirm);
        findViewById(R.id.btn_register).setOnClickListener(v -> submit());
        findViewById(R.id.btn_to_login).setOnClickListener(v -> finish());
    }

    private void submit() {
        tilName.setError(null);
        tilEmail.setError(null);
        tilPass.setError(null);
        tilConfirm.setError(null);
        String name = Util.str(etName), email = Util.str(etEmail), pass = Util.str(etPass),
                confirm = Util.str(etConfirm);
        boolean bad = false;
        if (name.trim().length() < 3) {
            tilName.setError("Name must be at least 3 characters"); bad = true;
        } else if (!Util.validName(name)) {
            tilName.setError("Use letters and spaces only"); bad = true;
        }
        if (!Util.validEmail(email)) { tilEmail.setError("Enter a valid email address"); bad = true; }
        if (pass.length() < 6) {
            tilPass.setError("At least 6 characters"); bad = true;
        } else if (!Util.validPassword(pass)) {
            tilPass.setError("Include at least one digit"); bad = true;
        }
        if (!pass.equals(confirm)) { tilConfirm.setError("Passwords do not match"); bad = true; }
        if (bad) return;

        boolean created = DbHelper.get(this).register(name, email, pass);
        if (!created) {
            tilEmail.setError("An account with this email already exists");
            Snackbar.make(findViewById(R.id.root), "An account with this email already exists",
                    Snackbar.LENGTH_LONG).show();
            return;
        }
        Session.save(this, email.trim().toLowerCase(java.util.Locale.US));
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
