package com.uol.campusfind;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
    public interface OnClick { void onClick(Item item); }

    private List<Item> items = new ArrayList<>();
    private List<String> distances;
    private final OnClick click;

    public ItemAdapter(OnClick click) {
        this.click = click;
    }

    public void setData(List<Item> items, List<String> distances) {
        this.items = items;
        this.distances = distances;
        notifyDataSetChanged();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView avatar, title, type, returned, category, meta, distance;

        VH(View v) {
            super(v);
            avatar = v.findViewById(R.id.tv_avatar);
            title = v.findViewById(R.id.tv_title);
            type = v.findViewById(R.id.tv_type);
            returned = v.findViewById(R.id.tv_returned);
            category = v.findViewById(R.id.tv_category);
            meta = v.findViewById(R.id.tv_meta);
            distance = v.findViewById(R.id.tv_distance);
        }
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup p, int viewType) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_card, p, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Item it = items.get(pos);
        Context c = h.itemView.getContext();
        boolean lost = "Lost".equals(it.type);
        h.title.setText(it.title);
        h.avatar.setText(lost ? "L" : "F");
        h.avatar.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(c,
                lost ? R.color.error_container : R.color.primary_container)));
        h.avatar.setTextColor(ContextCompat.getColor(c,
                lost ? R.color.on_error_container : R.color.on_primary_container));
        h.type.setText(it.type.toUpperCase());
        h.type.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(c,
                lost ? R.color.error : R.color.primary)));
        h.returned.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(c, R.color.green)));
        h.returned.setVisibility("Returned".equals(it.status) ? View.VISIBLE : View.GONE);
        h.category.setText(it.category);
        h.category.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(c, R.color.secondary_container)));
        h.meta.setText(it.place + "  \u2022  " + Util.fmtDate(it.date));
        if (distances != null && pos < distances.size()) {
            h.distance.setText(distances.get(pos));
            h.distance.setVisibility(View.VISIBLE);
        } else {
            h.distance.setVisibility(View.GONE);
        }
        h.itemView.setOnClickListener(v -> click.onClick(it));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
