package com.uol.campusfind;

public final class Config {
    private Config() {}

    // ===== EDIT THESE BEFORE SUBMITTING =====
    public static final String GITHUB_URL = "https://github.com/your-username/campusfind";
    public static final String[] TEAM_MEMBERS = {
            "Member 1 - Name (Reg No)",
            "Member 2 - Name (Reg No)",
            "Member 3 - Name (Reg No)"
    };
    // ========================================

    public static final String[] CATEGORIES = {
            "Electronics", "Wallets & Cards", "Keys", "Books & Stationery", "Other"
    };
}
