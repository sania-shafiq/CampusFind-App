CampusFind - Native Android (Java), Material 3
1. Android Studio > File > Open > select THIS folder (the one containing settings.gradle).
2. Wait for "Gradle sync" to finish (needs internet the first time).
3. Choose your emulator at the top and press the green Run button.
4. Edit team members / GitHub link in app/src/main/java/com/uol/campusfind/Config.java
5. Emulator GPS: "..." > Location > enter 31.38955, 74.24070 > Send location.
